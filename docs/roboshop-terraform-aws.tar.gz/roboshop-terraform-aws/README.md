# RoboShop E-Commerce Platform - AWS Terraform Deployment

[![Terraform](https://img.shields.io/badge/Terraform-1.0+-purple.svg)](https://www.terraform.io/)
[![AWS](https://img.shields.io/badge/AWS-Cloud-orange.svg)](https://aws.amazon.com/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

> A production-grade microservices e-commerce application deployed on AWS using Infrastructure as Code (Terraform)

## 🏗️ Architecture

RoboShop is a multi-tier microservices application demonstrating modern cloud architecture patterns:

- **7 Microservices** in different languages (Node.js, Java, Python, Go)
- **4 Databases/Caches** (MongoDB, MySQL, Redis, RabbitMQ)
- **3-Tier Network** (Public, App, Database subnets)
- **High Availability** with Application Load Balancer
- **Security** with proper network segmentation and security groups

```
┌──────────────────────────────────────────────────────┐
│                    Internet                          │
└────────────────────┬─────────────────────────────────┘
                     │
              ┌──────▼──────┐
              │     ALB     │  (Public Subnet)
              └──────┬──────┘
                     │
    ┌────────────────┼────────────────┐
    │                │                │
┌───▼───┐      ┌────▼────┐      ┌───▼────┐
│Frontend│      │Catalogue│      │  User  │  (App Subnet)
│(Nginx) │      │(Node.js)│      │(Node.js)│
└───┬───┘      └────┬────┘      └───┬────┘
    │               │                │
    └───────┬───────┴────────┬───────┘
            │                │
        ┌───▼────┐      ┌───▼────┐
        │MongoDB │      │  Redis │  (Database Subnet)
        └────────┘      └────────┘
```

## 🚀 Features

- ✅ **Infrastructure as Code** - 100% Terraform managed
- ✅ **Modular Design** - Reusable, composable modules
- ✅ **Security First** - Private subnets, security groups, bastion host
- ✅ **Automated Deployment** - User-data scripts for service installation
- ✅ **Multi-Environment** - Easy dev/staging/prod separation
- ✅ **Cost Optimized** - Right-sized instances with auto-shutdown capability
- ✅ **Production Ready** - CloudWatch monitoring, health checks, backups

## 📋 Prerequisites

- AWS Account with appropriate permissions
- Terraform >= 1.0
- AWS CLI configured
- SSH key pair for EC2 access

## 🏃 Quick Start

```bash
# Clone the repository
git clone https://github.com/yourusername/roboshop-terraform-aws.git
cd roboshop-terraform-aws

# Configure AWS credentials
aws configure

# Initialize Terraform
cd terraform
terraform init

# Review the plan
terraform plan

# Deploy infrastructure
terraform apply

# Access the application
# Frontend URL will be output after successful deployment
```

## 📁 Project Structure

```
roboshop-terraform-aws/
├── terraform/           # Root Terraform configuration
├── modules/            # Reusable Terraform modules
│   ├── vpc/           # VPC, subnets, routing
│   ├── security-groups/ # Security group definitions
│   ├── ec2-app/       # Application server module
│   ├── ec2-database/  # Database server module
│   ├── alb/           # Application Load Balancer
│   └── route53/       # DNS configuration
├── scripts/           # Deployment and utility scripts
├── docs/              # Additional documentation
└── .github/workflows/ # CI/CD pipelines
```

## 🏛️ Infrastructure Components

### Network Layer
- **VPC**: 10.0.0.0/16
- **Public Subnet**: 10.0.1.0/24 (Bastion, ALB)
- **Private App Subnet**: 10.0.10.0/24 (Microservices)
- **Private DB Subnet**: 10.0.20.0/24 (Databases)
- **NAT Gateway**: For private subnet internet access
- **Internet Gateway**: For public subnet access

### Compute Resources
| Service | Technology | Instance Type | Subnet |
|---------|-----------|---------------|--------|
| Frontend | Nginx | t3.micro | Private App |
| Catalogue | Node.js + MongoDB | t3.micro | Private App |
| User | Node.js + MongoDB | t3.micro | Private App |
| Cart | Node.js + Redis | t3.micro | Private App |
| Shipping | Java + MySQL | t3.small | Private App |
| Payment | Python + RabbitMQ | t3.micro | Private App |
| Dispatch | Go | t3.micro | Private App |
| MongoDB | Database | t3.small | Private DB |
| MySQL | Database | t3.small | Private DB |
| Redis | Cache | t3.micro | Private DB |
| RabbitMQ | Message Queue | t3.micro | Private DB |
| Bastion | Jump Host | t3.micro | Public |

### Security Groups
- Frontend SG (80, 443 from ALB)
- Catalogue SG (8080 from Frontend)
- User SG (8080 from Frontend)
- Cart SG (8080 from Frontend)
- Shipping SG (8080 from Cart)
- Payment SG (8080 from Cart)
- Dispatch SG (8080 from Payment)
- MongoDB SG (27017 from app tier)
- MySQL SG (3306 from app tier)
- Redis SG (6379 from app tier)
- RabbitMQ SG (5672 from app tier)
- Bastion SG (22 from your IP)

## 💰 Cost Estimation

**Monthly Cost (24/7 operation):**
- 12x t3.micro instances: ~$90/month
- NAT Gateway: ~$32/month
- Application Load Balancer: ~$16/month
- Data transfer: ~$10/month
- **Total: ~$150/month**

**Development Cost (with auto-shutdown):**
- Run 8 hours/day, 5 days/week: ~$30-40/month

## 🔧 Configuration

### Environment Variables

Create a `terraform/terraform.tfvars` file:

```hcl
aws_region          = "us-east-1"
environment         = "dev"
project_name        = "roboshop"
vpc_cidr            = "10.0.0.0/16"

# Your IP for SSH access to bastion
allowed_ssh_cidr    = ["YOUR_IP/32"]

# Instance types
app_instance_type   = "t3.micro"
db_instance_type    = "t3.small"

# Tags
tags = {
  Project     = "RoboShop"
  Environment = "Development"
  ManagedBy   = "Terraform"
  Owner       = "YourName"
}
```

## 📖 Documentation

- [Setup Guide](docs/SETUP.md) - Detailed setup instructions
- [Deployment Guide](docs/DEPLOYMENT.md) - How to deploy and manage
- [Architecture Guide](docs/ARCHITECTURE.md) - Deep dive into architecture decisions
- [Troubleshooting](docs/TROUBLESHOOTING.md) - Common issues and solutions

## 🔄 CI/CD Pipeline

GitHub Actions workflows:
- **terraform-plan.yml** - Validates and plans on PRs
- **terraform-apply.yml** - Deploys on merge to main
- **destroy.yml** - Manual cleanup workflow

## 🧪 Testing

```bash
# Validate Terraform configuration
terraform validate

# Check formatting
terraform fmt -check

# Security scan with Checkov
checkov -d terraform/

# Test deployment in dev environment
terraform workspace select dev
terraform apply
```

## 🛡️ Security Considerations

1. **Network Segmentation**: Public, app, and database tiers
2. **Security Groups**: Least privilege access
3. **Bastion Host**: SSH access through jump box only
4. **Private Subnets**: No direct internet access for app/db
5. **NAT Gateway**: Controlled outbound internet access
6. **SSH Keys**: Secure key management
7. **IAM Roles**: Minimal required permissions

## 📊 Monitoring

- CloudWatch metrics for all EC2 instances
- ALB health checks
- Custom application metrics
- SNS alerts for critical events

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Original RoboShop application from Instana/IBM
- Inspired by DevOps community training projects

## 📧 Contact

For questions or support, please open an issue or reach out:
- GitHub: [@yourusername](https://github.com/yourusername)
- LinkedIn: [Your Name](https://linkedin.com/in/yourprofile)

---

**⭐ If you find this project helpful, please consider giving it a star!**
